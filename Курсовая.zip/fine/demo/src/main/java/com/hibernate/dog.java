package com.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "dog")
public class dog {
    @Id
    @Column(name = "id_dog")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_dog;

    @Column(name = "dogname")
    private String dogname;

    @ManyToOne// Связь с классом breed
    @JoinColumn(name = "dog_breed_id", nullable = false)
    private breed breed;

    @ManyToOne
    @JoinColumn(name = "id_of_owner", referencedColumnName = "owner_id")
    private owner_list owner_list;

    public void setBid(breed dog_breed) {
        this.breed = dog_breed;
    }

    public breed getBid() {
        return breed;
    }

    public void setDid(int id_dog) {
        this.id_dog = id_dog;
    }

    public int getDid() {
        return id_dog;
    }

    public void setOid(owner_list id_of_owner) {
        this.owner_list = id_of_owner;
    }

    public owner_list getOid() {
        return owner_list;
    }

    public breed getBname() {
        return breed;
    }

    public void setDname(String dogname) {
        this.dogname = dogname;
    }

    public String getDname() {
        return dogname;
    }

    @Override
    public String toString() {
        return dogname; // Возвращаем кличку собаки
    }

    public dog() {
    }
}