package com.hibernate;

class OnlyLettersException extends Exception {
    public static String message="Error! You can write only letters and '-'.";
    
        public OnlyLettersException() {
            super(message);
    }

    @Override
    public String getMessage() {
        return message;
    }
}