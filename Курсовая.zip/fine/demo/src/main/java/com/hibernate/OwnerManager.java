package com.hibernate;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class OwnerManager {
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("test_persistence");

    public static void loadOwners(DefaultTableModel model) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
    
        List<owner_list> grist = em.createQuery("SELECT f FROM owner_list f WHERE owner_id > 0", owner_list.class).getResultList();
        model.setRowCount(0);
    
        if (grist.isEmpty()) {
            System.out.println("NO ROWS IN TABLE");
        } else {
            for (owner_list jj : grist) {
                model.addRow(new Object[]{jj.getOname(), jj.getOsurname()});
            }
        }
    
        em.getTransaction().commit();
        em.close();
    }
    public static int getOwnerIdByNameAndSurname(String name, String surname) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            owner_list owner = em.createQuery("SELECT o FROM owner_list o WHERE o.owner_name = :name AND o.owner_surname = :surname", owner_list.class)
                                 .setParameter("name", name)
                                 .setParameter("surname", surname)
                                 .getSingleResult();
            return owner.getOid();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An error occurred while retrieving the owner ID: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return -1;
        } finally {
            em.close();
        }
    }
    

    public static int addOwner(DefaultTableModel model, String name, String surname) {
        if (name != null && surname != null && !name.trim().isEmpty() && !surname.trim().isEmpty()) {
            EntityManager em = null;
            try {
                em = emf.createEntityManager();
                em.getTransaction().begin();
                owner_list newOwner = new owner_list();
                newOwner.setOname(name);
                newOwner.setOsurname(surname);
                em.persist(newOwner); 
    
                em.flush(); 
                em.getTransaction().commit();
                model.addRow(new Object[]{name, surname});
                return newOwner.getOid();
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                JOptionPane.showMessageDialog(null, "An error occurred while adding the owner: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                return -1; 
            } finally {
                if (em != null) {
                    em.close();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "All fields must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return -1; 
        }
    }

    public static void editOwner(DefaultTableModel model, JTable table) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String currentName = model.getValueAt(selectedRow, 0).toString();
            String currentSurname = model.getValueAt(selectedRow, 1).toString();
            String newName = JOptionPane.showInputDialog("Enter new Name:", currentName);
            String newSurname = JOptionPane.showInputDialog("Enter new Surname:", currentSurname);
    
            if (newName != null && newSurname != null && !newName.trim().isEmpty() && !newSurname.trim().isEmpty()) {
                EntityManager em = null;
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    owner_list owner = em.createQuery("SELECT o FROM owner_list o WHERE o.owner_name = :name AND o.owner_surname = :surname", owner_list.class)
                                         .setParameter("name", currentName)
                                         .setParameter("surname", currentSurname)
                                         .getSingleResult();
                    if (owner == null) {
                        JOptionPane.showMessageDialog(null, "Owner not found.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    owner.setOname(newName);
                    owner.setOsurname(newSurname);
                    em.getTransaction().commit();
                    model.setValueAt(newName, selectedRow, 0);
                    model.setValueAt(newSurname, selectedRow, 1);
                } catch (PersistenceException e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    JOptionPane.showMessageDialog(null, "An error occurred while editing the owner: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    JOptionPane.showMessageDialog(null, "An unexpected error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    if (em != null) {
                        em.close();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "All fields must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Select a row to edit.", "Selection Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

    public static void deleteOwner(DefaultTableModel model, JTable table) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int confirmation = JOptionPane.showConfirmDialog(
                null,
                "Are you sure you want to delete the selected owner and all associated data?",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
            );
            if (confirmation == JOptionPane.YES_OPTION) {
                EntityManager em = null;
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    String currentName = model.getValueAt(selectedRow, 0).toString();
                    String currentSurname = model.getValueAt(selectedRow, 1).toString();
                    owner_list owner = em.createQuery("SELECT o FROM owner_list o WHERE o.owner_name = :name AND o.owner_surname = :surname", owner_list.class)
                                         .setParameter("name", currentName)
                                         .setParameter("surname", currentSurname)
                                         .getSingleResult();
                    if (owner != null) {
                        int ownerId = owner.getOid();
                        Query deleteDogsQuery = em.createQuery("DELETE FROM dog d WHERE id_of_owner = :ownerId");
                        deleteDogsQuery.setParameter("ownerId", ownerId);
                        em.remove(owner);
    
                        em.getTransaction().commit();
                        model.removeRow(selectedRow);
                        JOptionPane.showMessageDialog(null, "Owner and associated dogs were deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Owner not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    JOptionPane.showMessageDialog(null, "An error occurred while deleting the owner: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    if (em != null) {
                        em.close();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Deletion canceled.", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Select a row to delete.", "Selection Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    


}
