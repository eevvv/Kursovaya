package com.hibernate;

class InvalidCredentialsException extends Exception {
    public static String message="Invalid credentials!";
    
        public InvalidCredentialsException() {
            super(message);
    }

    @Override
    public String getMessage() {
        return message;
    }
}