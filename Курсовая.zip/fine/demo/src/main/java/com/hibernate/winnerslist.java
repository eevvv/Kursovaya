package com.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "winnerslist")
public class winnerslist {
    @Id
    @Column(name = "id_winner")
    @GeneratedValue(strategy=  GenerationType.IDENTITY)
    private int id_winner;

    @ManyToOne
    @JoinColumn(name = "winnerdog_id", referencedColumnName = "id_dog")
    private dog dog;


    public void setWid(int id_winner){
        this.id_winner=id_winner;
    }
    
    public int getWid(){
        return id_winner;
    }

    public void setDid(dog dogwinner_id){
        this.dog=dogwinner_id;
    }
    
    public int getDid(){
        return dog.getDid();
    }

    // Новый метод getDog
    public dog getDog() {
        return dog;
    }

    public winnerslist()
    {

    }
}
