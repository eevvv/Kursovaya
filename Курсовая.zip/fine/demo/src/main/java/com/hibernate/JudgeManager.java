package com.hibernate;

import java.awt.Component;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class JudgeManager {
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("test_persistence");

    public static void loadJudges(DefaultTableModel model) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        List<judgelist> judges = em.createQuery("SELECT j FROM judgelist j", judgelist.class).getResultList();
        model.setRowCount(0);

        if (judges.isEmpty()) {
            System.out.println("NO ROWS IN TABLE");
        } else {
            for (judgelist judge : judges) {
                model.addRow(new Object[]{judge.getJname(), judge.getJsurname()});
            }
        }

        em.getTransaction().commit();
        em.close();
    }

    public static List<judgelist> getJudges() {
        EntityManager em = null;
        List<judgelist> judges = null;
        try {
            em = emf.createEntityManager();
            em.getTransaction().begin();
            judges = em.createQuery("SELECT j FROM judgelist j", judgelist.class).getResultList();

            em.getTransaction().commit();
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace(); 
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return judges;
    }

    public static void addJudge(String name, String surname, DefaultTableModel model) {
        if (name != null && surname != null && !name.trim().isEmpty() && !surname.trim().isEmpty()) {
            EntityManager em = null;
            try {
                em = emf.createEntityManager();
                em.getTransaction().begin();
                List<judgelist> existingJudges = em.createQuery("SELECT j FROM judgelist j WHERE j.judge_name = :name AND j.judge_surname = :surname", judgelist.class)
                                                    .setParameter("name", name)
                                                    .setParameter("surname", surname)
                                                    .getResultList();
    
                judgelist judge;
                if (existingJudges.isEmpty()) {
                    judge = new judgelist();
                    judge.setJname(name);
                    judge.setJsurname(surname);
                    em.persist(judge);
                    em.flush(); 
                } else {
                    judge = existingJudges.get(0);
                }
                em.getTransaction().commit();
                int id_judge = judge.getJid();
                List<breed> breeds = em.createQuery("SELECT b FROM breed b", breed.class).getResultList();
                JComboBox<breed> breedComboBox = new JComboBox<>(breeds.toArray(new breed[0]));
                breedComboBox.setRenderer(new DefaultListCellRenderer() {
                    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHeight) {
                        if (value instanceof breed) {
                            breed b = (breed) value;
                            value = b.getBname(); 
                        }
                        return super.getListCellRendererComponent(list, value, index, isSelected, cellHeight);
                    }
                });
                int result = JOptionPane.showConfirmDialog(null, breedComboBox, "Select Breed", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    breed selectedBreed = (breed) breedComboBox.getSelectedItem();
                    if (selectedBreed != null) {
                        int id_breed = selectedBreed.getBid(); 
                        List<breed_judge_list> existingLinks = em.createQuery("SELECT bjl FROM breed_judge_list bjl WHERE bjl.id_of_judge = :id_judge AND bjl.id_of_breed = :id_breed", breed_judge_list.class)
                                                                  .setParameter("id_judge", id_judge)
                                                                  .setParameter("id_breed", id_breed)
                                                                  .getResultList();
    
                        if (!existingLinks.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "This judge is already linked to this breed.", "Info", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            addJudgeBreedLink(id_judge, id_breed, model);
                        }
                    }
                }
    
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                JOptionPane.showMessageDialog(null, "An error occurred while adding the judge: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                if (em != null) {
                    em.close();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "All fields must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private static void addJudgeBreedLink(int id_judge, int id_breed, DefaultTableModel model) {
        EntityManager em = null;
        try {
            em = emf.createEntityManager();
            em.getTransaction().begin();
            List<breed_judge_list> existingLinks = em.createQuery("SELECT bjl FROM breed_judge_list bjl WHERE bjl.id_of_judge = :id_judge AND bjl.id_of_breed = :id_breed", breed_judge_list.class)
                                                      .setParameter("id_judge", id_judge)
                                                      .setParameter("id_breed", id_breed)
                                                      .getResultList();
    
            if (!existingLinks.isEmpty()) {
                JOptionPane.showMessageDialog(null, "This judge is already linked to this breed.", "Info", JOptionPane.INFORMATION_MESSAGE);
                return; 
            }
            breed_judge_list breedJudgeList = new breed_judge_list();
        breedJudgeList.setId_of_judge(id_judge);
        breedJudgeList.setId_of_breed(id_breed);
        judgelist judge = em.find(judgelist.class, id_judge);
        breed breed = em.find(breed.class, id_breed);

        breedJudgeList.setJudge(judge);
        breedJudgeList.setBreed(breed);

        em.persist(breedJudgeList);

        em.getTransaction().commit();
        System.out.println("Link between judge and breed added successfully.");

        judgelist addedJudge = em.find(judgelist.class, id_judge);
        breed addedBreed = em.find(breed.class, id_breed);
        if (addedJudge != null && addedBreed != null) {
            model.addRow(new Object[]{
                addedJudge.getJname(),                  
                addedJudge.getJsurname(),               
                addedBreed.getBname()                   
            });
        } else {
            JOptionPane.showMessageDialog(null, "Couldn't find the judge or breed.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (Exception e) {
        if (em != null && em.getTransaction().isActive()) {
            em.getTransaction().rollback();
        }
        JOptionPane.showMessageDialog(null, "An error occurred while adding the judge-breed link: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        if (em != null) {
            em.close(); 
        }
    }
}
public static void editJudge(DefaultTableModel model, JTable table) {
    int selectedRow = table.getSelectedRow();
    if (selectedRow != -1) {
        String currentName = model.getValueAt(selectedRow, 0).toString();
        String currentSurname = model.getValueAt(selectedRow, 1).toString();
        String currentBreed = model.getValueAt(selectedRow, 2).toString();

        String newName = JOptionPane.showInputDialog(null, "Enter new Name:", currentName);
        String newSurname = JOptionPane.showInputDialog(null, "Enter new Surname:", currentSurname);
        
        List<breed> breeds = JudgeManager.getBreeds(); 
        JComboBox<breed> breedComboBox = new JComboBox<>(breeds.toArray(new breed[0]));
        breedComboBox.setSelectedItem(currentBreed); 
        int result = JOptionPane.showConfirmDialog(null, breedComboBox, "Select New Breed", JOptionPane.OK_CANCEL_OPTION);
        breed selectedBreed = (result == JOptionPane.OK_OPTION) ? (breed) breedComboBox.getSelectedItem() : null;

        if (newName != null && newSurname != null && selectedBreed != null) {
            EntityManager em = null;
            try {
                em = JudgeManager.emf.createEntityManager();
                em.getTransaction().begin();
                judgelist judge = em.createQuery("SELECT j FROM judgelist j WHERE j.judge_name = :name AND j.judge_surname = :surname", judgelist.class)
                                     .setParameter("name", currentName)
                                     .setParameter("surname", currentSurname)
                                     .getSingleResult();

                if (judge != null) {
                    judge.setJname(newName.trim());
                    judge.setJsurname(newSurname.trim());
                    breed_judge_list existingLink = em.createQuery("SELECT bjl FROM breed_judge_list bjl WHERE bjl.id_of_judge = :id_judge AND bjl.id_of_breed = (SELECT b.id FROM breed b WHERE b.name_of_breed = :currentBreed)", breed_judge_list.class)
                                                       .setParameter("id_judge", judge.getJid())
                                                       .setParameter("currentBreed", currentBreed)
                                                       .getSingleResult();
                    if (existingLink != null) {
                        em.remove(existingLink);
                    }
                    breed_judge_list newLink = new breed_judge_list();
                    newLink.setId_of_judge(judge.getJid());
                    newLink.setId_of_breed(selectedBreed.getBid());
                    newLink.setJudge(judge);
                    newLink.setBreed(em.merge(selectedBreed)); 
                    em.persist(newLink);

                    em.getTransaction().commit(); 
                    model.setValueAt(newName, selectedRow, 0);
                    model.setValueAt(newSurname, selectedRow, 1);
                    model.setValueAt(selectedBreed.getBname(), selectedRow, 2);

                    JOptionPane.showMessageDialog(null, "Judge details updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Judge not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NoResultException e) {
                JOptionPane.showMessageDialog(null, "No existing link found for the judge and breed.", "Info", JOptionPane.INFORMATION_MESSAGE);
                em.getTransaction().commit();
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                JOptionPane.showMessageDialog(null, "An error occurred while editing the judge: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                if (em != null) {
                    em.close();
 }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Editing canceled.", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "No judge selected for editing.", "Warning", JOptionPane.WARNING_MESSAGE);
    }
}

public static List<breed> getBreeds() {
    EntityManager em = null;
    List<breed> breeds = null;
    try {
        em = emf.createEntityManager();
        em.getTransaction().begin();
        breeds = em.createQuery("SELECT b FROM breed b", breed.class).getResultList();

        em.getTransaction().commit();
    } catch (Exception e) {
        if (em != null && em.getTransaction().isActive()) {
            em.getTransaction().rollback();
        }
        e.printStackTrace(); 
    } finally {
        if (em != null) {
            em.close();
        }
    }
    return breeds;
}
                        
public static void deleteJudgeWithBreed(DefaultTableModel model, JTable table) {
    int selectedRow = table.getSelectedRow();
    if (selectedRow != -1) {
        int confirmation = JOptionPane.showConfirmDialog(
                null,
                "Are you sure you want to delete the selected judge and all associated breed links?",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
                        
        if (confirmation == JOptionPane.YES_OPTION) {
            EntityManager em = null;
            try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    String judgeName = model.getValueAt(selectedRow, 0).toString();
                    String judgeSurname = model.getValueAt(selectedRow, 1).toString();
                    Query deleteLinksQuery = em.createNativeQuery(
                                                "DELETE FROM breed_judge_list WHERE id_of_judge = (SELECT id_judge FROM judgelist WHERE judge_name = :judgeName AND judge_surname = :judgeSurname)"
                    );
                    deleteLinksQuery.setParameter("judgeName", judgeName);
                    deleteLinksQuery.setParameter("judgeSurname", judgeSurname);
                    deleteLinksQuery.executeUpdate();
                    judgelist judge = em.createQuery("SELECT j FROM judgelist j WHERE j.judge_name = :judgeName AND j.judge_surname = :judgeSurname", judgelist.class)
                                                                 .setParameter("judgeName", judgeName)
                                                                 .setParameter("judgeSurname", judgeSurname)
                                                                 .getSingleResult();
                    if (judge != null) {
                         em.remove(judge);
                    }
                    em.getTransaction().commit();
                        
                    model.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(null, "Judge and associated data were successfully deleted.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception e) {
                            if (em != null && em.getTransaction().isActive()) {
                                                em.getTransaction().rollback();
                                            }
                                            JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                                            e.printStackTrace();
                    } finally {
                            if (em != null) {
                                                em.close();
                                            }
                             }
                }
                } else {
                                    JOptionPane.showMessageDialog(null, "Select a row to delete.", "Selection Error", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                        
}