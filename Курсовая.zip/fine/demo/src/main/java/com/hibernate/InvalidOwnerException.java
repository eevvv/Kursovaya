package com.hibernate;

public class InvalidOwnerException extends Exception {
    public static String message="Owner doesn't exist";
    
        public InvalidOwnerException() {
            super(message);
    }

    @Override
    public String getMessage() {
        return message;
    }
}