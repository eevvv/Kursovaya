package com.hibernate;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name = "breed_judge_list")
public class breed_judge_list implements Serializable {

    @Id
    @JoinColumn(name = "id_of_judge")
    private int id_of_judge; // id судьи

    @Id
    @JoinColumn(name = "id_of_breed")
    private int id_of_breed; // id породы

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_of_judge", referencedColumnName = "id_judge", insertable = false, updatable = false)
    private judgelist judge;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_of_breed", referencedColumnName = "id_breed", insertable = false, updatable = false)
    private breed breed;

    // Геттеры и сеттеры
    public int getId_of_judge() {
        return id_of_judge;
    }

    public void setId_of_judge(int id_of_judge) {
        this.id_of_judge = id_of_judge;
    }

    public int getId_of_breed() {
        return id_of_breed;
    }

    public void setId_of_breed(int id_of_breed) {
        this.id_of_breed = id_of_breed;
    }

    public judgelist getJudge() {
        return judge;
    }

    public void setJudge(judgelist judge) {
        this.judge = judge;
    }

    public breed getBreed() {
        return breed;
    }

    public void setBreed(breed breed) {
        this.breed = breed;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        breed_judge_list that = (breed_judge_list) o;
        return Objects.equals(id_of_judge, that.id_of_judge) &&
               Objects.equals(id_of_breed, that.id_of_breed);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id_of_judge, id_of_breed);
    }
    
    public breed_judge_list() {

    }
}
