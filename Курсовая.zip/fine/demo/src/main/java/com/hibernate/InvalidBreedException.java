package com.hibernate;

public class InvalidBreedException extends Exception {
    public static String message="Breed doesn't exist";
    
        public InvalidBreedException() {
            super(message);
    }

    @Override
    public String getMessage() {
        return message;
    }
}