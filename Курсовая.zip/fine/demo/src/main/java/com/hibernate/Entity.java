package com.hibernate;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import org.apache.log4j.Logger;

public class Entity {

   private static final Logger log = Logger.getLogger(Entity.class);
   private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("test_persistence");

   public static DefaultTableModel currentModel;

   public static class CustomException extends Exception {
       public CustomException() {
           super("You didn't write anything");
       }
       
        public CustomException(String string) {
           }
          }
       
          public static void main(String[] args) {
              log.info("Starting the Dog's Show application");
              SwingUtilities.invokeLater(Entity::createLoginFrame);
       
              EntityManagerFactory emf = Persistence.createEntityManagerFactory("test_persistence");
              EntityManager em = emf.createEntityManager();
          }



          
//                                                                      НАЧАЛО РАБОТЫ С ПРИЛОЖЕНИЕМ. АВТОРИЗАЦИЯ/ВХОД В ПРОФИЛЬ АДМИНИСТРАТОРА ВЫСТАВКИ.
private static void createLoginFrame() {
    JFrame loginFrame = new JFrame("Admin Login");
    loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    loginFrame.setLayout(new GridLayout(3, 2));

    JLabel userLabel = new JLabel("Username:");
    JTextField userField = new JTextField();
    JLabel passLabel = new JLabel("Password:");
    JPasswordField passField = new JPasswordField();
    JButton loginButton = new JButton("Login");

    loginFrame.add(userLabel);
    loginFrame.add(userField);
    loginFrame.add(passLabel);
    loginFrame.add(passField);
    loginFrame.add(new JLabel());
    loginFrame.add(loginButton);

    loginFrame.setSize(300, 150);
    loginFrame.setLocationRelativeTo(null);
    loginFrame.setVisible(true);

    loginButton.addActionListener(e -> {
        String username = userField.getText();
        String password = new String(passField.getPassword());

        try {
            if (authenticate(username, password)) {
                log.info("Admin logged in successfully: " + username);
                loginFrame.dispose();
                SwingUtilities.invokeLater(Entity::openMainApplication);
            }
        } catch (InvalidCredentialsException ex) {
            log.error("Failed login attempt with username: " + username);
            JOptionPane.showMessageDialog(loginFrame, ex.getMessage(), "Login Error", JOptionPane.ERROR_MESSAGE);
        }
    });
}

private static boolean authenticate(String username, String password) throws InvalidCredentialsException {
    final String ADMIN_USERNAME = "admin";
    final String ADMIN_PASSWORD = "123";
    if (ADMIN_USERNAME.equals(username) && ADMIN_PASSWORD.equals(password)) {
        return true;
    } else {
        throw new InvalidCredentialsException();
    }
}
       
       //                                                                          ОТКРЫТИЕ ОСНОВНОГО ПРИЛОЖЕНИЯ
private static void openMainApplication() {
              JFrame frame = new JFrame("Dog's Show");
              frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
              frame.setLayout(new BorderLayout());
              JLabel headerLabel = new JLabel("Welcome to our Dog's Show! Here you can find all the information about our Judges, Dogs and their Owners", JLabel.CENTER);
              frame.getContentPane().add(headerLabel, BorderLayout.NORTH);
              JPanel buttonPanel = new JPanel(new GridLayout(3, 2));
       
              JButton jBtn = new JButton("Judges with breeds");
              JButton oBtn = new JButton("Owners");
              JButton dBtn = new JButton("Dogs");
              JButton bBtn = new JButton("Breeds");
              JButton wBtn = new JButton("Winners");
              JButton JBtn = new JButton("Judges");
       
              buttonPanel.add(jBtn);
              buttonPanel.add(oBtn);
              buttonPanel.add(dBtn);
              buttonPanel.add(bBtn);
              buttonPanel.add(wBtn);
              buttonPanel.add(JBtn);
       
              frame.getContentPane().add(buttonPanel, BorderLayout.CENTER);
              frame.setSize(1000, 500);
              frame.setVisible(true);
       
              jBtn.addActionListener(e -> showBJTable());
              oBtn.addActionListener(e -> showOwnerTable());
              dBtn.addActionListener(e -> showDogTable());
              bBtn.addActionListener(e -> showBreedTable());
              wBtn.addActionListener(e -> showWinnerTable());
              JBtn.addActionListener(e -> showJudgesTable());
          }
       
//                                                                            ТАБЛИЧКА С СУДЬЯМИ И ПОРОДАМИ, КОТОРЫЕ ОНИ ОБСЛУЖИВАЮТ 
         
public static void showBJTable() {
        JFrame tableFrame = new JFrame("Judges with Breeds");
        tableFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Judge Name");
        model.addColumn("Judge Surname");
        model.addColumn("Breed Name");
        JTable table = new JTable(model);
    
        
        EntityManager em = null;
        try {
            em = emf.createEntityManager();
            em.getTransaction().begin();
    
            String jpql = "SELECT b, j FROM breed_judge_list bj " + "JOIN bj.breed b " + "JOIN bj.judge j";
            Query query = em.createQuery(jpql);
            List<Object[]> results = query.getResultList();
            model.setRowCount(0);
    
            for (Object[] result : results) {
                breed breed = (breed) result[0];  
                judgelist judge = (judgelist) result[1];  
    
                model.addRow(new Object[]{ judge.getJname(), judge.getJsurname(), breed.getBname()});
            }
            originalData = new ArrayList<>(results);
    
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (em != null) {
                em.close(); 
            }
        }
    
        JScrollPane scrollPane = new JScrollPane(table);
        tableFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
        tableFrame.setSize(500, 600);
    
        JButton addBtn = new JButton("Add");
        JButton editBtn = new JButton("Edit");
        JButton deleteBtn = new JButton("Delete");
        JButton searchBtn = new JButton("Search");
        addBtn.addActionListener(e -> addJudge(model));
        editBtn.addActionListener(e -> JudgeManager.editJudge(model, table));
        deleteBtn.addActionListener(e -> JudgeManager.deleteJudgeWithBreed(model, table));
        searchBtn.addActionListener(e -> {
            try {
                JTextField searchField = new JTextField(20);
                searchField.setText(lastSearchTerm); 
                int result = JOptionPane.showConfirmDialog(tableFrame, searchField, "Enter search term:", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    String searchTerm = searchField.getText();
                    if (!isValidSearchTerm(searchTerm)) {
                        throw new CustomException("Search term can only contain letters (A-Z, a-z), spaces, and hyphens (-).");
                    }
                    log.info("Search initiated in Judges table with term: " + searchTerm);
                    lastSearchTerm = searchTerm; 
                    int foundCount = filterTable(model, searchTerm);
                    JOptionPane.showMessageDialog(tableFrame, "Found elements: " + foundCount);
                }
            } catch (CustomException ex) {
                showErrorDialog("Error", ex.getMessage());
            }
        });
    
        JPanel controlPanel = new JPanel();
        controlPanel.add(addBtn);
        controlPanel.add(editBtn);
        controlPanel.add(deleteBtn);
        controlPanel.add(searchBtn);
    
        tableFrame.getContentPane().add(controlPanel, BorderLayout.SOUTH);
        tableFrame.setVisible(true);
    }
    private static boolean isValidSearchTerm(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return false; 
        }
        return searchTerm.matches("[A-Za-z-]+"); 
    }
    
    public static int filterTable(DefaultTableModel model, String searchTerm) throws CustomException {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            log.error("Search term is empty or null.");
            throw new CustomException("Search term cannot be empty.");
        }
        int foundCount = 0;
        List<Object[]> matchingRows = new ArrayList<>();
        for (Object[] result : originalData) {
            breed breed = (breed) result[0];  
            judgelist judge = (judgelist) result[1];
            String name = judge.getJname(); 
            String surname = judge.getJsurname(); 
            String breedName = breed.getBname(); 
            if (name.contains(searchTerm) ||
                surname.contains(searchTerm) ||
                breedName.contains(searchTerm)) {
                matchingRows.add(new Object[]{name, surname, breedName});
                foundCount++;
            }
        }
        model.setRowCount(0);
        for (Object[] row : matchingRows) {
            model.addRow(row);
        }
        log.info("Search completed with foundCount: " + foundCount);
        return foundCount;
    }
    
    private static void addJudge(DefaultTableModel model) {
        try {
            String[] options = {"New Judge", "Existing Judge"};
            int choice = JOptionPane.showOptionDialog(null, "Would you like to add a new judge or select an existing one?", "Judge Selection", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            if (choice == 0) { 
                String name = JOptionPane.showInputDialog("Enter Name:");
                if (name == null || name.trim().isEmpty()) {
                    throw new IllegalArgumentException("Name cannot be empty.");
                }
                String surname = JOptionPane.showInputDialog("Enter Surname:");
                if (surname == null || surname.trim().isEmpty()) {
                    throw new IllegalArgumentException("Surname cannot be empty.");
                }
                if (!name.matches("[A-Za-z-]+") || !surname.matches("[A-Za-z-]+")) {
                    throw new OnlyLettersException();
                }
                JudgeManager.addJudge(name, surname, model);
    
            } else if (choice == 1) { 
                List<judgelist> judges = JudgeManager.getJudges(); 
                JComboBox<judgelist> judgeComboBox = new JComboBox<>(judges.toArray(new judgelist[0]));
                judgeComboBox.setRenderer(new DefaultListCellRenderer() {
                    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHeight) {
                        if (value instanceof judgelist) {
                            judgelist j = (judgelist) value;
                            value = j.getJname() + " " + j.getJsurname(); 
                        }
                        return super.getListCellRendererComponent(list, value, index, isSelected, cellHeight);
                    }
                });
                int result = JOptionPane.showConfirmDialog(null, judgeComboBox, "Select Existing Judge", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    judgelist selectedJudge = (judgelist) judgeComboBox.getSelectedItem();
                    if (selectedJudge != null) {
                        String name = selectedJudge.getJname();
                        String surname = selectedJudge.getJsurname();
                        JudgeManager.addJudge(name, surname, model);
                    }
                }
            } else {
                return;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "An unexpected error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
private static String lastSearchTerm = ""; 
private static List<Object[]> originalData = new ArrayList<>(); 
    



//                                                                                      ТАБЛИЧКА С ВЛАДЕЛЬЦАМИ СОБАК
private static void showOwnerTable() {
    JFrame tableFrame = new JFrame("Owners");
    tableFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    DefaultTableModel model = new DefaultTableModel() {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    JTable table = new JTable(model);
    currentModel = model;
    model.addColumn("Name");
    model.addColumn("Surname");
    OwnerManager.loadOwners(model);
    JScrollPane scrollPane = new JScrollPane(table);
    tableFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    tableFrame.setSize(1000, 500);
    table.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent e) {
            if (e.getClickCount() == 2) {
                int row = table.getSelectedRow();
                if (row != -1) {
                    String ownerName = model.getValueAt(row, 0).toString();
                    String ownerSurname = model.getValueAt(row, 1).toString();
                    int ownerId = OwnerManager.getOwnerIdByNameAndSurname(ownerName, ownerSurname);
                    try {
                        showDogsByOwner(ownerId, ownerName, ownerSurname);
                    } catch (NoDogsException ex) {
                    }
                }
            }
        }
    });

    JButton addBtn = new JButton("Add");
    JButton editBtn = new JButton("Edit");
    JButton deleteBtn = new JButton("Delete");

    addBtn.addActionListener(e -> addOwnerWithDog(model));
    editBtn.addActionListener(e -> OwnerManager.editOwner(model, table));
    deleteBtn.addActionListener(e -> OwnerManager.deleteOwner(model, table));

    JTextField searchField = new JTextField(20);
    JButton searchBtn = new JButton("Search");
    searchBtn.addActionListener(e -> {
        String searchTerm = searchField.getText();
        if (searchTerm.isEmpty()) {
            // Если поле поиска пустое, можно либо не выполнять фильтрацию, либо выполнить фильтрацию с пустым строковым значением
            filterTableO("", model, table);
        } else if (isValidSearchTerm(searchTerm)) {
            filterTableO(searchTerm, model, table);
        } else {
            try {
                throw new OnlyLettersException();
            } catch (OnlyLettersException ex) {
                showErrorDialog("Error", ex.getMessage());
            }
        }
    });
    searchField.addActionListener(e -> searchBtn.doClick());

    JPanel controlPanel = new JPanel();
    controlPanel.add(addBtn);
    controlPanel.add(editBtn);
    controlPanel.add(deleteBtn);
    controlPanel.add(new JLabel("Search:"));
    controlPanel.add(searchField);
    controlPanel.add(searchBtn);

    tableFrame.getContentPane().add(controlPanel, BorderLayout.SOUTH);
    tableFrame.setVisible(true);
}

private static void addOwnerWithDog(DefaultTableModel model) {

    JFrame addOwnerFrame = new JFrame("Add Owner and Dog");
    addOwnerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    addOwnerFrame.setSize(300, 300);

    // Создаем панель для ввода данных
    JPanel panel = new JPanel(new GridLayout(5, 2));
    JTextField ownerNameField = new JTextField();
    JTextField ownerSurnameField = new JTextField();
    JTextField dogNameField = new JTextField();
    JComboBox<breed> breedComboBox = new JComboBox<>();

    EntityManager em = DogOfOwnerManager.emf.createEntityManager();
    try {
        List<breed> breeds = em.createQuery("SELECT b FROM breed b", breed.class).getResultList();
        for (breed b : breeds) {
            breedComboBox.addItem(b);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(addOwnerFrame, "Error loading breeds: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        em.close(); // Закрываем EntityManager после загрузки пород
    }

    panel.add(new JLabel("Owner Name:"));
    panel.add(ownerNameField);
    panel.add(new JLabel("Owner Surname:"));
    panel.add(ownerSurnameField);
    panel.add(new JLabel("Dog Name:"));
    panel.add(dogNameField);
    panel.add(new JLabel("Breed:"));
    panel.add(breedComboBox);

    JButton addButton = new JButton("Add");
    addButton.setPreferredSize(new Dimension(200, 50));
    addButton.addActionListener(e -> {
        String ownerName = ownerNameField.getText();
        String ownerSurname = ownerSurnameField.getText();
        String dogName = dogNameField.getText();
        breed selectedBreed = (breed) breedComboBox.getSelectedItem();
        String regex = "^[a-zA-Z-]+$";
        if (!ownerName.matches(regex)) {
            JOptionPane.showMessageDialog(addOwnerFrame, "Owner Name must contain only English letters and hyphens.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!ownerSurname.matches(regex)) {
            JOptionPane.showMessageDialog(addOwnerFrame, "Owner Surname must contain only English letters and hyphens.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!dogName.matches(regex)) {
            JOptionPane.showMessageDialog(addOwnerFrame, "Dog Name must contain only English letters and hyphens.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        EntityManager em2 = DogOfOwnerManager.emf.createEntityManager();
        em2.getTransaction().begin();
        if (ownerName != null && ownerSurname != null && dogName != null && selectedBreed != null && !ownerName.trim().isEmpty() && !ownerSurname.trim().isEmpty() && !dogName.trim().isEmpty()) {
            try {
                owner_list newOwner = new owner_list();
                newOwner.setOname(ownerName);
                newOwner.setOsurname(ownerSurname);
                newOwner = em2.merge(newOwner); 
                em2.flush();
                dog newDog = new dog();
                newDog.setDname(dogName);
                newDog.setBid(selectedBreed);
                newDog.setOid(newOwner);
                newDog = em2.merge(newDog); 
                em2.getTransaction().commit(); 
                JOptionPane.showMessageDialog(addOwnerFrame, "Owner and dog added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                addOwnerFrame.dispose();
                model.addRow(new Object[]{ownerName, ownerSurname});
            } catch (Exception ex) {
                em2.getTransaction().rollback(); 
                JOptionPane.showMessageDialog(addOwnerFrame, "An error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                em2.close(); 
            }
        } else {
            JOptionPane.showMessageDialog(addOwnerFrame, "All fields must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    });
    panel.add(addButton);
    addOwnerFrame.getContentPane().add(panel);
    addOwnerFrame.setVisible(true);
}
private static void filterTableO(String searchTerm, DefaultTableModel model, JTable table) {
    TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
    table.setRowSorter(sorter);
    if (searchTerm.isEmpty()) {
        sorter.setRowFilter(null); // Показать все строки
    } else {
        sorter.setRowFilter(RowFilter.regexFilter(searchTerm, 0, 1));
    }
}
 
private static void loadDogsByOwner(DefaultTableModel model, int ownerId) {
    EntityManager em = DogOfOwnerManager.emf.createEntityManager();
    try {
        List<dog> dogs = em.createQuery("SELECT d FROM dog d WHERE id_of_owner = :ownerId", dog.class)
                           .setParameter("ownerId", ownerId)
                           .getResultList();
        model.setRowCount(0); 
        for (dog d : dogs) {
            model.addRow(new Object[]{d.getDname(), d.getBid().getBname()});
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error loading dogs: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        em.close(); 
    }
}
private static void showDogsByOwner(int ownerId, String ownerName, String ownerSurname) throws NoDogsException {
    JFrame dogsFrame = new JFrame("Dogs Owned by Owner ID: " + ownerId + " - " + ownerName + " " + ownerSurname);
    dogsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    DefaultTableModel dogsModel = new DefaultTableModel();
    JTable dogsTable = new JTable(dogsModel);
    dogsModel.addColumn("Dog Name");
    dogsModel.addColumn("Breed Name");
    try {
        loadDogsByOwner(dogsModel, ownerId);
        JScrollPane scrollPane = new JScrollPane(dogsTable);
        dogsFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
        dogsFrame.setSize(800, 400);

        JButton addDogBtn = new JButton("Add Dog");
        JButton editDogBtn = new JButton("Edit Dog");
        JButton deleteDogBtn = new JButton("Delete Dog");

        addDogBtn.addActionListener(e -> addDogForOwner(ownerId, dogsModel, dogsTable));
        editDogBtn.addActionListener(e -> DogOfOwnerManager.editDog(dogsModel, dogsTable));
        deleteDogBtn.addActionListener(e -> DogOfOwnerManager.deleteDog(dogsModel, dogsTable));

        JPanel controlPanel = new JPanel();
        controlPanel.add(addDogBtn);
        controlPanel.add(editDogBtn);
        controlPanel.add(deleteDogBtn);

        dogsFrame.getContentPane().add(controlPanel, BorderLayout.SOUTH);
        dogsFrame.setVisible(true);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(dogsFrame, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        dogsFrame.dispose();
    }
}

private static void addDogForOwner(int ownerId, DefaultTableModel model, JTable table) {
    JFrame addDogFrame = new JFrame("Add Dog");
    addDogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    addDogFrame.setSize(300, 200);

    JPanel panel = new JPanel(new GridLayout(3, 2));
    JTextField nameField = new JTextField();
    JComboBox<breed> breedComboBox = new JComboBox<>();

    EntityManager em = DogOfOwnerManager.emf.createEntityManager();
    try {
        List<breed> breeds = em.createQuery("SELECT b FROM breed b", breed.class).getResultList();
        for (breed b : breeds) {
            breedComboBox.addItem(b);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(addDogFrame, "Error loading breeds: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        em.close(); 
    }

    panel.add(new JLabel("Name:"));
    panel.add(nameField);
    panel.add(new JLabel("Breed:"));
    panel.add(breedComboBox);

    JButton addButton = new JButton("Add Dog");
    addButton.addActionListener(e -> {
        String name = nameField.getText();
        breed selectedBreed = (breed) breedComboBox.getSelectedItem();
        EntityManager em2 = DogOfOwnerManager.emf.createEntityManager();
        em2.getTransaction().begin();
        String regex = "^[a-zA-Z-]+$";
        if (!name.matches(regex)) {
            JOptionPane.showMessageDialog(addDogFrame, "Owner's info must contain only English letters and '-'.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (name != null && selectedBreed != null && !name.trim().isEmpty()) {
            try {
                owner_list owner = em2.find(owner_list.class, ownerId);
                if (owner == null) {
                    throw new InvalidOwnerException();
                }
                DogOfOwnerManager.addDogFromOwners(em2, name, selectedBreed, owner); 

                em2.getTransaction().commit(); 
                JOptionPane.showMessageDialog(addDogFrame, "Dog added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                addDogFrame.dispose();

                loadDogsByOwner(model, ownerId);
            } catch (InvalidOwnerException ioe) {
                if (em2.getTransaction().isActive()) {
                    em2.getTransaction().rollback(); 
                }
                JOptionPane.showMessageDialog(addDogFrame, ioe.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                if (em2.getTransaction().isActive()) {
                    em2.getTransaction().rollback(); 
                }
                JOptionPane.showMessageDialog(addDogFrame, "An error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                em2.close(); 
            }
        } else {
            JOptionPane.showMessageDialog(addDogFrame, "All fields must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    panel.add(addButton);
    addDogFrame.getContentPane().add(panel);
    addDogFrame.setVisible(true);
}
    

    





//                                                                                ТАБЛИЧКА С СОБАЧКАМИ
private static void showDogTable() {
    JFrame tableFrame = new JFrame("Dogs");
    tableFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    DefaultTableModel model = new DefaultTableModel();
    JTable table = new JTable(model);
    currentModel = model;

    model.addColumn("Name");
    model.addColumn("Breed");
    model.addColumn("Owner");
    DogManager.loadDogs(model);
    JScrollPane scrollPane = new JScrollPane(table);
    tableFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    tableFrame.setSize(1000, 500);

    JButton addBtn = new JButton("Add");
    JButton editBtn = new JButton("Edit");
    JButton deleteBtn = new JButton("Delete");
    JButton searchBtn = new JButton("Search");

    addBtn.addActionListener(e -> DogManager.addDog(model));
    editBtn.addActionListener(e -> DogManager.editDog(model, table));
    deleteBtn.addActionListener(e -> DogManager.deleteDog(model, table));

    JTextField searchField = new JTextField(20);

    searchBtn.addActionListener(e -> filterTableD(searchField.getText(), model, table));
    searchField.addActionListener(e -> searchBtn.doClick()); 
    JPanel controlPanel = new JPanel();
    controlPanel.add(addBtn);
    controlPanel.add(editBtn);
    controlPanel.add(deleteBtn);
    controlPanel.add(new JLabel("Search:"));
    controlPanel.add(searchField);

    tableFrame.getContentPane().add(controlPanel, BorderLayout.SOUTH);
    tableFrame.setVisible(true);
}

private static void filterTableD(String searchTerm, DefaultTableModel model, JTable table) {
    TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
    table.setRowSorter(sorter);
    String regex = "^[a-zA-Z-]+$";
    if (!searchTerm.matches(regex)) {
        
            JFrame tableFrame = new JFrame();
            JOptionPane.showMessageDialog(tableFrame, "Information of Dog must contain only English letters and hyphens.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
    }
    else{
    sorter.setRowFilter(RowFilter.regexFilter(searchTerm, 0, 1, 2));}
}






//                                                                                        ТАБЛИЧКА С ПОРОДАМИ
private static void showBreedTable() {
    JFrame tableFrame = new JFrame("Breeds");
    tableFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    DefaultTableModel model = new DefaultTableModel() {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; 
        }
    };
    JTable table = new JTable(model);
    currentModel = model;
    model.addColumn("ID");
    model.addColumn("Name");

    BreedManager.loadBreeds(model);

    JScrollPane scrollPane = new JScrollPane(table);
    tableFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    tableFrame.setSize(1000, 500);
    table.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent e) {
            if (e.getClickCount() == 2) { 
                int row = table.getSelectedRow();
                if (row != -1) {
                    int breedId = (int) model.getValueAt(row, 0);
                    showOwnersTable(breedId); 
                }
            }
        }
    });

    JButton addBtn = new JButton("Add");
    JButton editBtn = new JButton("Edit");
    JButton deleteBtn = new JButton("Delete");
    JButton searchBtn = new JButton("Search");
    JButton reportBtn = new JButton("Generate report");

    addBtn.addActionListener(e -> addBreed(model));
    editBtn.addActionListener(e -> BreedManager.editBreed(model, table));
    deleteBtn.addActionListener(e -> BreedManager.deleteBreed(model, table));
    reportBtn.addActionListener(e -> {
        try {
            BreedReport.generateReport("BreedReport.pdf");
            JOptionPane.showMessageDialog(null, "Report generated successfully as BreedReport.pdf", 
                                          "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Failed to generate report: " + ex.getMessage(), 
                                          "Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    JTextField searchField = new JTextField(20);
    searchBtn.addActionListener(e -> filterTableB(searchField.getText(), model, table));
    searchField.addActionListener(e -> searchBtn.doClick()); 
    JPanel controlPanel = new JPanel();
    controlPanel.add(addBtn);
    controlPanel.add(editBtn);
    controlPanel.add(deleteBtn);
    controlPanel.add(reportBtn);
    controlPanel.add(new JLabel("Search:"));
    controlPanel.add(searchField);

    tableFrame.getContentPane().add(controlPanel, BorderLayout.SOUTH);
    tableFrame.setVisible(true);
}

private static void filterTableB(String searchTerm, DefaultTableModel model, JTable table) {
    TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
    table.setRowSorter(sorter);
    String regex = "^[a-zA-Z-]+$";
    if (!searchTerm.matches(regex)) {
            JFrame tableFrame = new JFrame();
            JOptionPane.showMessageDialog(tableFrame, "Breeds must contain only English letters and hyphens.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
    }
    else{
    sorter.setRowFilter(RowFilter.regexFilter(searchTerm,  1)); }
}
private static void addBreed(DefaultTableModel model) {
        String name = JOptionPane.showInputDialog("Enter Name of breed:");

        String regex = "^[a-zA-Z-]+$";
        if (!name.matches(regex)) {
            JFrame tableFrame = new JFrame();
            JOptionPane.showMessageDialog(tableFrame, "Breed Name must contain only English letters and '-'.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }else{
        BreedManager.addBreed(model, name);}
}
private static void showOwnersTable(int breedId) {
        EntityManager em = emf.createEntityManager();
        String breedName = null;
    
        try {
            em.getTransaction().begin();
            breed breed = em.find(breed.class, breedId);
            if (breed != null) {
                breedName = breed.getBname(); 
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            JOptionPane.showMessageDialog(null, "An error occurred while loading breed name: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            if (em != null) {
                em.close();
            }
        }
        JFrame ownersFrame = new JFrame("Owners of Breed: " + (breedName != null ? breedName : "Unknown"));
        ownersFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    
        DefaultTableModel ownersModel = new DefaultTableModel();
        JTable ownersTable = new JTable(ownersModel);
        ownersModel.addColumn("Owner Name");
        ownersModel.addColumn("Owner Surname");
        loadOwnersByBreed(ownersModel, breedId);
    
        JScrollPane scrollPane = new JScrollPane(ownersTable);
        ownersFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
        ownersFrame.setSize(800, 400);
        ownersFrame.setVisible(true);
    }
    
private static void loadOwnersByBreed(DefaultTableModel model, int dog_breed_id) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            List<dog> dogs = em.createQuery("SELECT d FROM dog d WHERE dog_breed_id = :dog_breed_id", dog.class)
                    .setParameter("dog_breed_id", dog_breed_id)
                    .getResultList();
            Set<Integer> uniqueOwnerIds = new HashSet<>();
    
            for (dog d : dogs) {
                owner_list owner = d.getOid(); 
                if (owner != null) { 
                    if (!uniqueOwnerIds.contains(owner.getOid())) {
                        uniqueOwnerIds.add(owner.getOid()); 
                        model.addRow(new Object[]{owner.getOname(), owner.getOsurname()});
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            JOptionPane.showMessageDialog(null, "An error occurred while loading owners: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
    




//                                                                                       ТАБЛИЧКА С ПОБЕДИТЕЛЯМИ    
private static void showWinnerTable() {
    JFrame tableFrame = new JFrame("Winners");
    tableFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    DefaultTableModel model = new DefaultTableModel();
    JTable table = new JTable(model);
    currentModel = model;
    model.addColumn("ID Winner");
    model.addColumn("Dog Name"); 
    model.addColumn("Breed"); 

    WinnerManager.loadWinners(model);

    JScrollPane scrollPane = new JScrollPane(table);
    tableFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    tableFrame.setSize(1000, 500);
    JButton addBtn = new JButton("Add");
    JButton editBtn = new JButton("Edit");
    JButton deleteBtn = new JButton("Delete");
    JButton searchBtn = new JButton("Search");

    addBtn.addActionListener(e -> addWinner(model));
    editBtn.addActionListener(e -> WinnerManager.editWinner(model, table));
    deleteBtn.addActionListener(e -> WinnerManager.deleteWinner(model, table));
    JTextField searchField = new JTextField(20);

    searchBtn.addActionListener(e -> filterTableW(searchField.getText(), model, table));
    searchField.addActionListener(e -> searchBtn.doClick()); 

    JPanel controlPanel = new JPanel();
    controlPanel.add(addBtn);
    controlPanel.add(editBtn);
    controlPanel.add(deleteBtn);
    controlPanel.add(new JLabel("Search:"));
    controlPanel.add(searchField);
    tableFrame.getContentPane().add(controlPanel, BorderLayout.SOUTH);
    tableFrame.setVisible(true);
}
private static void filterTableW(String searchTerm, DefaultTableModel model, JTable table) {
    TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
    table.setRowSorter(sorter);
    String regex = "^[a-zA-Z-]+$";
    if (!searchTerm.matches(regex)) {
            JFrame tableFrame = new JFrame();
            JOptionPane.showMessageDialog(tableFrame, "Winner's info must contain only English letters and hyphens.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
    }
    else{
    sorter.setRowFilter(RowFilter.regexFilter(searchTerm, 0, 1, 2));}
}

public static void addWinner(DefaultTableModel model) {
    JFrame winnerFrame = new JFrame("Add Winner");
    winnerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    winnerFrame.setSize(400, 300);
    
    JPanel panel = new JPanel(new GridLayout(3, 2)); 
    JComboBox<breed> breedComboBox = new JComboBox<>();
    JComboBox<dog> dogComboBox = new JComboBox<>(); 
    EntityManager em = DogManager.emf.createEntityManager();
    try {
        List<breed> breeds = em.createQuery("SELECT b FROM breed b", breed.class).getResultList();
        for (breed b : breeds) {
            breedComboBox.addItem(b);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(winnerFrame, "Error loading breeds: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        em.close();
    }
    breedComboBox.addActionListener(e -> {
        dogComboBox.removeAllItems(); 
        breed selectedBreed = (breed) breedComboBox.getSelectedItem();
        if (selectedBreed != null) {
            EntityManager em2 = DogManager.emf.createEntityManager();
            try {
                List<dog> dogs = em2.createQuery("SELECT d FROM dog d WHERE dog_breed_id = :dog_breed_id", dog.class)
                        .setParameter("dog_breed_id", selectedBreed)
                        .getResultList();
                for (dog d : dogs) {
                    dogComboBox.addItem(d);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(winnerFrame, "Error loading dogs: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                em2.close();
            }
        }
    });

    panel.add(new JLabel("Select Breed:"));
    panel.add(breedComboBox);
    panel.add(new JLabel("Select Dog:"));
    panel.add(dogComboBox);

    JButton addButton = new JButton("Add Winner");
    addButton.addActionListener(e -> {
        dog selectedDog = (dog) dogComboBox.getSelectedItem();
        if (selectedDog != null) {
            int winnerDogId = selectedDog.getDid(); 
            try {
                WinnerManager.addWinner(model, winnerDogId); 
                JOptionPane.showMessageDialog(winnerFrame, "Winner added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                winnerFrame.dispose(); 
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(winnerFrame, "An error occurred while adding the winner: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(winnerFrame, "Please select a dog.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    panel.add(addButton);
    winnerFrame.getContentPane().add(panel); 
    winnerFrame.setVisible(true); 
}




//                                                                      ТАБЛИЧКА ТОЛЬКО С СУДЬЯМИ
private static void showJudgesTable() {
    JFrame tableFrame = new JFrame("Judges");
    tableFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    DefaultTableModel model = new DefaultTableModel() {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; 
        }
    };
    JTable table = new JTable(model);
    currentModel = model;

    model.addColumn("Name");
    model.addColumn("Surname");

    JManager.loadJ(model);

    JScrollPane scrollPane = new JScrollPane(table);
    tableFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
    tableFrame.setSize(1000, 500);
    JButton addBtn = new JButton("Add");
    JButton editBtn = new JButton("Edit");
    JButton deleteBtn = new JButton("Delete");
    JButton searchBtn = new JButton("Search");

    addBtn.addActionListener(e -> addJudges(model));
        editBtn.addActionListener(e -> JManager.editJ(model, table));
        deleteBtn.addActionListener(e -> JManager.deleteJ(model, table));
    JTextField searchField = new JTextField(20);

    searchBtn.addActionListener(e -> filterTableJudge(searchField.getText(), model, table));
    searchField.addActionListener(e -> searchBtn.doClick()); 

    JPanel controlPanel = new JPanel();
    controlPanel.add(addBtn);
    controlPanel.add(editBtn);
    controlPanel.add(deleteBtn);
    controlPanel.add(new JLabel("Search:"));
    controlPanel.add(searchField);

    
        tableFrame.getContentPane().add(controlPanel, BorderLayout.SOUTH);
        tableFrame.setVisible(true);
    }
    private static void filterTableJudge(String searchTerm, DefaultTableModel model, JTable table) {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);
        String regex = "^[a-zA-Z-]+$";
        if (!searchTerm.matches(regex)) {
        
            JFrame tableFrame = new JFrame();
            JOptionPane.showMessageDialog(tableFrame, "Judge's info must contain only English letters and hyphens.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
         }
         else{
        sorter.setRowFilter(RowFilter.regexFilter(searchTerm, 0, 1));}
    }
    
    private static void addJudges(DefaultTableModel model) {
    String name = JOptionPane.showInputDialog("Enter Name:");
    String surname = JOptionPane.showInputDialog("Enter Surname:");
    JManager.addJ(name, surname, model);
}

    public static int filterTable(String searchTerm) throws CustomException {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            log.error("Search term is empty or null.");
            throw new CustomException();
        }
 
        int rowCount = currentModel.getRowCount();
        int foundCount = 0;
 
        for (int i = rowCount - 1; i >= 0; i--) {
            boolean matchFound = false;
            for (int j = 0; j < currentModel.getColumnCount(); j++) {
                if (currentModel.getValueAt(i, j) != null &&
                    currentModel.getValueAt(i, j).toString().toLowerCase().contains(searchTerm.toLowerCase())) {
                    matchFound = true;
                    break;
                }
            }
            if (matchFound) {
                foundCount++;
            } else {
                currentModel.removeRow(i);
            }
        }
 
        log.info("Search completed with foundCount: " + foundCount);
        return foundCount;
    }
    private static void showErrorDialog(String title, String message) {
       JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
   }
}