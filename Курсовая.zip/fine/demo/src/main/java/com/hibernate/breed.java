package com.hibernate;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "breed")
public class breed {
    @Id
    @Column(name = "id_breed")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_breed;

    @Column(name = "name_of_breed")
    private String name_of_breed;

    @OneToMany(mappedBy = "breed", cascade = CascadeType.ALL) // Связь с классом dog
    private List<dog> dogs; // Список собак, относящихся к этой породе

    public void setBid(int id_breed) {
        this.id_breed = id_breed;
    }

    public int getBid() {
        return id_breed;
    }

    public void setBname(String name_of_breed) {
        this.name_of_breed = name_of_breed;
    }

    public String getBname() {
        return name_of_breed;
    }

    public breed() {
    }

    public List<dog> getDogs() {
        return dogs;
    }

    public void setDogs(List<dog> dogs) {
        this.dogs = dogs;
    }

    @Override
    public String toString() {
        return name_of_breed; // Возвращаем название породы
    }
}