package com.hibernate;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "owner_list")
public class owner_list implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "owner_id")
    @GeneratedValue(strategy=  GenerationType.IDENTITY)
    private int owner_id;

    @Column(name ="owner_name")
    private String owner_name;

    @Column(name ="owner_surname")
    private String owner_surname;


    public void setOid(int owner_id){
        this.owner_id=owner_id;
    }
    
    public int getOid(){
        return owner_id;
    }

    public void setOname(String owner_name){
        this.owner_name=owner_name;
    }
    public String getOname(){
        return owner_name;
    }

    public void setOsurname(String owner_surname){
        this.owner_surname=owner_surname;
    }
    public String getOsurname(){
        return owner_surname;
    }

    public owner_list()
    {

    }
}
