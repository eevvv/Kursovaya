package com.hibernate;
public class NoDogsException extends Exception {
    public NoDogsException(String message) {
        super(message);
    }
}