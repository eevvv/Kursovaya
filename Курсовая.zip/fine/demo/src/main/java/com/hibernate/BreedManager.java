package com.hibernate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;

public class BreedManager {
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("test_persistence");

    public static void loadBreeds(DefaultTableModel model) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        List<breed> grist = em.createQuery("SELECT f FROM breed f WHERE id_breed > 0", breed.class).getResultList();

        model.setRowCount(0);

        if (grist.isEmpty()) {
            System.out.println("NO ROWS IN TABLE");
        } else {
            for (breed jj : grist) {
                model.addRow(new Object[]{jj.getBid(), jj.getBname()});
            }
        }

        em.getTransaction().commit();
        em.close();
    }

    public static void addBreed(DefaultTableModel model, String name) {
        if (name != null &&  !name.trim().isEmpty() ) {
            EntityManager em = null;
            try {
                em = emf.createEntityManager();
                em.getTransaction().begin();
                breed newBreed = new breed();
                newBreed.setBname(name);
                em.persist(newBreed); 
    
                em.getTransaction().commit();
                model.addRow(new Object[]{newBreed.getBid(), name});
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                JOptionPane.showMessageDialog(null, "An error occurred while adding the breed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                if (em != null) {
                    em.close();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "All fields must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static void editBreed(DefaultTableModel model, JTable table) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String currentId = model.getValueAt(selectedRow, 0).toString();
            String name = JOptionPane.showInputDialog("Enter new Name:", model.getValueAt(selectedRow, 1));
    
            if (name != null &&  !name.trim().isEmpty()) {
                EntityManager em = null;
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    breed breed = em.find(breed.class, Integer.parseInt(currentId));
                    if (breed == null) {
                        JOptionPane.showMessageDialog(null, "Breed not found.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    breed.setBname(name);
                    em.getTransaction().commit();
                    model.setValueAt(name, selectedRow, 1);
                } catch (PersistenceException e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    JOptionPane.showMessageDialog(null, "An error occurred while editing the breed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    JOptionPane.showMessageDialog(null, "An unexpected error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    if (em != null) {
                        em.close();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "All fields must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Select a row to edit.", "Selection Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void deleteBreed(DefaultTableModel model, JTable table) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a breed to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        int breedId = (int) model.getValueAt(selectedRow, 0);
        int confirm = JOptionPane.showConfirmDialog(null,
                "Are you sure you want to delete this breed and all associated dogs?",
                "Confirm Deletion", JOptionPane.YES_NO_OPTION);
    
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
    
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Query deleteDogsQuery = em.createQuery("DELETE FROM dog d WHERE dog_breed_id = :breedId");
            deleteDogsQuery.setParameter("breedId", breedId);
            int deletedDogsCount = deleteDogsQuery.executeUpdate();
            Query deleteJudgesQuery = em.createQuery("DELETE FROM breed_judge_list bj WHERE id_of_breed = :breedId");
            deleteJudgesQuery.setParameter("breedId", breedId);
            deleteJudgesQuery.executeUpdate();
    
            breed breedToDelete = em.find(breed.class, breedId);
            if (breedToDelete != null) {
                em.remove(breedToDelete);
                model.removeRow(selectedRow);
            } else {
                JOptionPane.showMessageDialog(null, "Breed not found.", "Error", JOptionPane.ERROR_MESSAGE);
                em.getTransaction().rollback();
                return;
            }
    
            em.getTransaction().commit();
            JOptionPane.showMessageDialog(null, "Breed and " + deletedDogsCount + " associated dogs deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            JOptionPane.showMessageDialog(null, "An error occurred while deleting breed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace(); 
        } finally {
            em.close();
        }
    }

public static void generateReport() {
        String dbUrl = "jdbc:mysql://localhost:3306/dogs__show?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        String username = "root"; 
        String password = "280105"; 
        String sqlQuery = "SELECT owner_id, owner_name, owner_surname FROM judgelist";

        String template = "C:/Users/rabov/OneDrive/Рабочий стол/для уникс/ооп/Tree.jrxml"; 
        String resultPath = "C:/Users/rabov/report1.pdf"; 

        try (Connection connection = DriverManager.getConnection(dbUrl, username, password);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sqlQuery)) {
            JRDataSource ds = new JRResultSetDataSource(resultSet);

            JasperReport jasperReport = JasperCompileManager.compileReport(template);

            JasperPrint print = JasperFillManager.fillReport(jasperReport, new HashMap<>(), ds);

            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setExporterInput(new SimpleExporterInput(print));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(resultPath));
            exporter.exportReport();

            JOptionPane.showMessageDialog(null, "Report generated successfully: " + resultPath);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "An error during report generation: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}