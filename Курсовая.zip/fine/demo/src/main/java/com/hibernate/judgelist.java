package com.hibernate;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "judgelist")
public class judgelist {
    @Id
    @Column(name = "id_judge")
    @GeneratedValue(strategy=  GenerationType.IDENTITY)
    private int id_judge;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable (name="breed_judge_list",
       joinColumns=@JoinColumn (name="id_of_judge"),
       inverseJoinColumns=@JoinColumn(name="id_of_breed"))
    private List<breed> breeds;
    

    @Column(name ="judge_name")
    private String judge_name;

    @Column(name ="judge_surname")
    private String judge_surname;

    public void setJid(int id_judge){
        this.id_judge=id_judge;
    }
    
    public int getJid(){
        return id_judge;
    }
    

    public void setJname(String judge_name){
        this.judge_name=judge_name;
    }
    public String getJname(){
        return judge_name;
    }

    public void setJsurname(String judge_surname){
        this.judge_surname=judge_surname;
    }
    public String getJsurname(){
        return judge_surname;
    }

    // Сеттер и геттер для breeds
    public List<breed> getBreeds() {
        return breeds;
    }

    public void setBreeds(List<breed> breeds) {
        this.breeds = breeds;
    }
    public judgelist()
    {

    }
}
