package com.hibernate;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DogOfOwnerManager {
    public static EntityManagerFactory emf = Persistence.createEntityManagerFactory("test_persistence");

    public static void addDogFromOwners(EntityManager em, String name, breed breed, owner_list owner) throws InvalidOwnerException {
        if (name == null || breed == null || owner == null || name.trim().isEmpty()) {
            throw new InvalidOwnerException();
        }
        try {
            dog newDog = new dog();
            newDog.setDname(name);
            newDog.setBid(breed);
            newDog.setOid(owner);
            em.persist(newDog); 
            em.flush();
        } catch (Exception e) {
            throw new InvalidOwnerException();
        }
    }
    public static List<breed> getBreeds() {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<breed> breeds = em.createQuery("SELECT b FROM breed b", breed.class).getResultList();
        em.getTransaction().commit();
        em.close();
        return breeds;
    }
    public static void editDog(DefaultTableModel model, JTable table) {
    int selectedRow = table.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(null, "Please select a row to edit.", "Selection Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    String currentName = (String) model.getValueAt(selectedRow, 0);
    String currentBreed = (String) model.getValueAt(selectedRow, 1);
    List<breed> breeds = DogManager.getBreeds();
    JComboBox<String> breedComboBox = new JComboBox<>();
    for (breed breed : breeds) {
        breedComboBox.addItem(breed.getBname());
    }
    breedComboBox.setSelectedItem(currentBreed);
    JPanel inputPanel = new JPanel();
    inputPanel.add(new JLabel("Name:"));
    JTextField nameField = new JTextField(currentName, 10);
    inputPanel.add(nameField);
    inputPanel.add(new JLabel("Breed:"));
    inputPanel.add(breedComboBox);

    int result = JOptionPane.showConfirmDialog(null, inputPanel, "Edit Dog", JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
        String newName = nameField.getText();
        String selectedBreed = (String) breedComboBox.getSelectedItem();

        if (newName != null && !newName.trim().isEmpty() && selectedBreed != null) {
            EntityManager em = null;
            try {
                em = DogOfOwnerManager.emf.createEntityManager();
                em.getTransaction().begin();
                breed selectedBreedObj = breeds.stream()
                        .filter(b -> b.getBname().equals(selectedBreed))
                        .findFirst()
                        .orElse(null);
                if (selectedBreedObj == null) {
                    JOptionPane.showMessageDialog(null, "Breed not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                dog currentDog = em.createQuery("SELECT d FROM dog d WHERE d.dogname = :name", dog.class)
                        .setParameter("name", currentName)
                        .getSingleResult();

                if (currentDog == null) {
                    JOptionPane.showMessageDialog(null, "Dog not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                currentDog.setDname(newName);
                currentDog.setBid(selectedBreedObj); 
                em.merge(currentDog);
                em.getTransaction().commit();
                model.setValueAt(newName, selectedRow, 0);
                model.setValueAt(selectedBreed, selectedRow, 1);
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                JOptionPane.showMessageDialog(null, "An error occurred while editing the dog: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                if (em != null) {
                    em.close();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "All fields must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}


    
public static void deleteDog(DefaultTableModel model, JTable table) {
    int selectedRow = table.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(null, "Please select a row to delete.", "Selection Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    String dogName = (String) model.getValueAt(selectedRow, 0);
    int confirmation = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the dog: " + dogName + "?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
    if (confirmation != JOptionPane.YES_OPTION) {
        return;
    }
    EntityManager em = null;
    try {
        em = emf.createEntityManager();
        em.getTransaction().begin();
        dog dogToDelete = em.createQuery("SELECT d FROM dog d WHERE d.dogname = :name", dog.class)
                .setParameter("name", dogName)
                .getSingleResult();

        if (dogToDelete == null) {
            JOptionPane.showMessageDialog(null, "Dog not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        em.remove(dogToDelete);
        em.getTransaction().commit();
        model.removeRow(selectedRow);
        JOptionPane.showMessageDialog(null, "Dog deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
    } catch (Exception e) {
        if (em != null && em.getTransaction().isActive()) {
            em.getTransaction().rollback();
        }
        JOptionPane.showMessageDialog(null, "An error occurred while deleting the dog: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        if (em != null) {
            em.close();
        }
    }
}


}
