package com.hibernate;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class DogManager {
    public static EntityManagerFactory emf = Persistence.createEntityManagerFactory("test_persistence");

    public static void loadDogs(DefaultTableModel model) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
    
        List<dog> grist = em.createQuery("SELECT f FROM dog f WHERE id_dog > 0", dog.class).getResultList();
        model.setRowCount(0);
    
        if (grist.isEmpty()) {
            System.out.println("NO ROWS IN TABLE");
        } else {
            for (dog jj : grist) {
                model.addRow(new Object[]{ jj.getDname(), jj.getBid().getBname(), jj.getOid().getOname() + " " + jj.getOid().getOsurname() });
            }
        }
    
        em.getTransaction().commit();
        em.close();
    }
    

    public static List<breed> getBreeds() {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<breed> breeds = em.createQuery("SELECT b FROM breed b", breed.class).getResultList();
        em.getTransaction().commit();
        em.close();
        return breeds;
    }
    
    public static List<owner_list> getOwners() {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<owner_list> owners = em.createQuery("SELECT o FROM owner_list o", owner_list.class).getResultList();
        em.getTransaction().commit();
        em.close();
        return owners;
    }
    
    public static void addDog(DefaultTableModel model) {
        List<breed> breeds = DogManager.getBreeds();
        List<owner_list> owners = DogManager.getOwners();

        JComboBox<String> breedComboBox = new JComboBox<>();
        JComboBox<String> ownerComboBox = new JComboBox<>();
        for (breed breed : breeds) {
            breedComboBox.addItem(breed.getBname());
        }
        for (owner_list owner : owners) {
            ownerComboBox.addItem(owner.getOname() + " " + owner.getOsurname());
        }
        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Name:"));
        JTextField nameField = new JTextField(10);
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Breed:"));
        inputPanel.add(breedComboBox);
        inputPanel.add(new JLabel("Owner:"));
        inputPanel.add(ownerComboBox);
        int result = JOptionPane.showConfirmDialog(null, inputPanel, "Add Dog", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String name = nameField.getText();
            String regex = "^[a-zA-Z-]+$";
            if (!name.matches(regex)) {
                JFrame tableFrame = new JFrame();
                JOptionPane.showMessageDialog(tableFrame, "Dog's info must contain only English letters and '-'.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String selectedBreed = (String) breedComboBox.getSelectedItem();
            String selectedOwner = (String) ownerComboBox.getSelectedItem();

            if (name != null && !name.trim().isEmpty() && selectedBreed != null && selectedOwner != null) {
                EntityManager em = null;
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    breed selectedBreedObj = breeds.stream()
                            .filter(b -> b.getBname().equals(selectedBreed))
                            .findFirst()
                            .orElse(null);

                    owner_list selectedOwnerObj = owners.stream()
                            .filter(o -> (o.getOname() + " " + o.getOsurname()).equals(selectedOwner))
                            .findFirst()
                            .orElse(null);
                    if (selectedBreedObj == null) {
                        JOptionPane.showMessageDialog(null, "Breed not found.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    if (selectedOwnerObj == null) {
                        JOptionPane.showMessageDialog(null, "Owner not found.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    dog newDog = new dog();
                    newDog.setDname(name);
                    newDog.setBid(selectedBreedObj); 
                    newDog.setOid(selectedOwnerObj); 
                    dog managedDog = em.merge(newDog);

                    em.getTransaction().commit();

                    model.addRow(new Object[]{
                        managedDog.getDname(), 
                        managedDog.getBid().getBname(), 
                        managedDog.getOid().getOname() + " " + managedDog.getOid().getOsurname() 
                    });
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    JOptionPane.showMessageDialog(null, "An error occurred while adding the dog: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    if (em != null) {
                        em.close();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "All fields must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
      
 public static void editDog(DefaultTableModel model, JTable table) {
    int selectedRow = table.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(null, "Please select a row to edit.", "Selection Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    String currentName = (String) model.getValueAt(selectedRow, 0);
    String currentBreed = (String) model.getValueAt(selectedRow, 1);
    String currentOwner = (String) model.getValueAt(selectedRow, 2);
    List<breed> breeds = DogManager.getBreeds();
    List<owner_list> owners = DogManager.getOwners();

    JComboBox<String> breedComboBox = new JComboBox<>();
    JComboBox<String> ownerComboBox = new JComboBox<>();
    for (breed breed : breeds) {
        breedComboBox.addItem(breed.getBname());
    }
    for (owner_list owner : owners) {
        ownerComboBox.addItem(owner.getOname() + " " + owner.getOsurname());
    }

    breedComboBox.setSelectedItem(currentBreed);
    ownerComboBox.setSelectedItem(currentOwner);

    JPanel inputPanel = new JPanel();
    inputPanel.add(new JLabel("Name:"));
    JTextField nameField = new JTextField(currentName, 10);
    inputPanel.add(nameField);
    inputPanel.add(new JLabel("Breed:"));
    inputPanel.add(breedComboBox);
    inputPanel.add(new JLabel("Owner:"));
    inputPanel.add(ownerComboBox);
    int result = JOptionPane.showConfirmDialog(null, inputPanel, "Edit Dog", JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
        String newName = nameField.getText();
        String selectedBreed = (String) breedComboBox.getSelectedItem();
        String selectedOwner = (String) ownerComboBox.getSelectedItem();
        if (newName != null && !newName.trim().isEmpty() && selectedBreed != null && selectedOwner != null) {
            EntityManager em = null;
            try {
                em = emf.createEntityManager();
                em.getTransaction().begin();
                breed selectedBreedObj = breeds.stream()
                        .filter(b -> b.getBname().equals(selectedBreed))
                        .findFirst()
                        .orElse(null);
                owner_list selectedOwnerObj = owners.stream()
                        .filter(o -> (o.getOname() + " " + o.getOsurname()).equals(selectedOwner))
                        .findFirst()
                        .orElse(null);
                if (selectedBreedObj == null) {
                    JOptionPane.showMessageDialog(null, "Breed not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (selectedOwnerObj == null) {
                    JOptionPane.showMessageDialog(null, "Owner not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                dog currentDog = em.createQuery("SELECT d FROM dog d WHERE d.dogname = :name", dog.class)
                        .setParameter("name", currentName)
                        .getSingleResult();

                if (currentDog == null) {
                    JOptionPane.showMessageDialog(null, "Dog not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                currentDog.setDname(newName);
                currentDog.setBid(selectedBreedObj); 
                currentDog.setOid(selectedOwnerObj); 
                em.merge(currentDog);

                em.getTransaction().commit();
                model.setValueAt(newName, selectedRow, 0);
                model.setValueAt(selectedBreed, selectedRow, 1);
                model.setValueAt(selectedOwner, selectedRow, 2);
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                JOptionPane.showMessageDialog(null, "An error occurred while editing the dog: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                if (em != null) {
                    em.close();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "All fields must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

public static void deleteDog(DefaultTableModel model, JTable table) {
    int selectedRow = table.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(null, "Please select a row to delete.", "Selection Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    String dogName = (String) model.getValueAt(selectedRow, 0);
    int confirmation = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the dog: " + dogName + "?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
    if (confirmation != JOptionPane.YES_OPTION) {
        return;
    }

    EntityManager em = null;
    try {
        em = emf.createEntityManager();
        em.getTransaction().begin();
        dog dogToDelete = em.createQuery("SELECT d FROM dog d WHERE d.dogname = :name", dog.class)
                .setParameter("name", dogName)
                .getSingleResult();

        if (dogToDelete == null) {
            JOptionPane.showMessageDialog(null, "Dog not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        em.remove(dogToDelete);

        em.getTransaction().commit();
        model.removeRow(selectedRow);
        JOptionPane.showMessageDialog(null, "Dog deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
    } catch (Exception e) {
        if (em != null && em.getTransaction().isActive()) {
            em.getTransaction().rollback();
        }
        JOptionPane.showMessageDialog(null, "An error occurred while deleting the dog: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        if (em != null) {
            em.close();
        }
    }
}






}