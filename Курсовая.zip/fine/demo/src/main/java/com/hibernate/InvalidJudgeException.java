package com.hibernate;

public class InvalidJudgeException extends Exception {
    public static String message="Incorrect input";
    
        public InvalidJudgeException() {
            super(message);
    }

    @Override
    public String getMessage() {
        return message;
    }
}