package com.hibernate;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;

class dataLoader extends SwingWorker<Void, Void> {
    private DefaultTableModel model;
    private String tagName;
    private String operation;

    public dataLoader(DefaultTableModel model, String tagName, String operation) {
        this.model = model;
        this.tagName = tagName;
        this.operation = operation;
    }

    @Override
    protected Void doInBackground() {
        switch (operation) {
            case "loadJudges":
                //Entity.loadDataFromXML(model, tagName);
                break;
            case "loadOwners":
                //Entity.loadDataFromXML(model, tagName);
                break;
            case "loadDogs":
               // Entity.loadDataFromXML_dogs(model, tagName);
                break;
            case "loadBreeds":
                //Entity.loadDataFromXML_breed(model, tagName);
                break;
            case "loadWinners":
                //Entity.loadDataFromXML_winners(model, tagName);
                break;
            default:
                throw new IllegalArgumentException("Invalid operation: " + operation);
        }
        return null;
    }

    @Override
    protected void done() {
        System.out.println("Data loading complete for " + operation);
    }
}
