package com.hibernate;

import java.awt.Component;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class JManager {
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("test_persistence");

    public static void loadJ(DefaultTableModel model) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        List<judgelist> judges = em.createQuery("SELECT j FROM judgelist j", judgelist.class).getResultList();
        model.setRowCount(0);

        for (judgelist judge : judges) {
            model.addRow(new Object[]{judge.getJname(), judge.getJsurname()});
        }

        em.getTransaction().commit();
        em.close();
    }

    public static void addJ(String name, String surname, DefaultTableModel model) {
        if (name != null && surname != null && !name.trim().isEmpty() && !surname.trim().isEmpty()) {
            EntityManager em = null;
            try {
                em = emf.createEntityManager();
                em.getTransaction().begin();
                judgelist newJudge = new judgelist();
                newJudge.setJname(name);
                newJudge.setJsurname(surname);
                em.persist(newJudge);
                em.getTransaction().commit();
                model.addRow(new Object[]{newJudge.getJname(), newJudge.getJsurname()});
                selectAndLinkBreed(newJudge.getJid());
            } catch (Exception e) {
                if (em != null && em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
                JOptionPane.showMessageDialog(null, "An error occurred while adding the judge: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                if (em != null) {
                    em.close();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "All fields must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void editJ(DefaultTableModel model, JTable table) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String currentName = model.getValueAt(selectedRow, 0).toString();
            String currentSurname = model.getValueAt(selectedRow, 1).toString();
    
            String name = JOptionPane.showInputDialog(null, "Enter new Name:", currentName);
            String surname = JOptionPane.showInputDialog(null, "Enter new Surname:", currentSurname);
    
            if (name != null && surname != null && !name.trim().isEmpty() && !surname.trim().isEmpty()) {
                EntityManager em = null;
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    judgelist judge = em.createQuery("SELECT j FROM judgelist j WHERE j.judge_name = :name AND j.judge_surname = :surname", judgelist.class)
                            .setParameter("name", currentName)
                            .setParameter("surname", currentSurname)
                            .getSingleResult();
    
                    if (judge != null) {
                        judge.setJname(name.trim());
                        judge.setJsurname(surname.trim());
                        em.getTransaction().commit();
                        model.setValueAt(name, selectedRow, 0); 
                        model.setValueAt(surname, selectedRow, 1); 
    
                        JOptionPane.showMessageDialog(null, "Judge successfully updated.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Judge not found in the database.", "Error", JOptionPane.ERROR_MESSAGE);
                        em.getTransaction().rollback();
                    }
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    JOptionPane.showMessageDialog(null, "An error occurred while editing the judge: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    if (em != null) {
                        em.close();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Both Name and Surname must be filled.", "Input Error", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select a row to edit.", "Selection Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    private static void selectAndLinkBreed(int judgeId) {
        EntityManager em = null;
        try {
            em = emf.createEntityManager();
            em.getTransaction().begin();
            List<breed> breeds = em.createQuery("SELECT b FROM breed b", breed.class).getResultList();
            JComboBox<breed> breedComboBox = new JComboBox<>(breeds.toArray(new breed[0]));
            breedComboBox.setRenderer(new DefaultListCellRenderer() {
                public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHeight) {
                    if (value instanceof breed) {
                        breed b = (breed) value;
                        value = b.getBname(); 
                    }
                    return super.getListCellRendererComponent(list, value, index, isSelected, cellHeight);
                }
            });
            int result = JOptionPane.showConfirmDialog(null, breedComboBox, "Select Breed", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                breed selectedBreed = (breed) breedComboBox.getSelectedItem();
                if (selectedBreed != null) {
                    int breedId = selectedBreed.getBid(); 
                    addJudgeBreedLink(judgeId, breedId);
                }
            }
    
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            JOptionPane.showMessageDialog(null, "An error occurred while linking breed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    private static void addJudgeBreedLink(int judgeId, int breedId) {
        EntityManager em = null;
        try {
            em = emf.createEntityManager();
            em.getTransaction().begin();
            breed_judge_list breedJudgeList = new breed_judge_list();
            breedJudgeList.setId_of_judge(judgeId);
            breedJudgeList.setId_of_breed(breedId);
            judgelist judge = em.find(judgelist.class, judgeId);
            breed breed = em.find(breed.class, breedId);
            if (judge == null || breed == null) {
                throw new Exception("Judge or Breed not found.");
            }
            breedJudgeList.setJudge(judge);
            breedJudgeList.setBreed(breed);
            em.persist(breedJudgeList);
            em.getTransaction().commit();
            System.out.println("Judge and breed linked successfully.");
        } catch (Exception e) {
            if (em != null && em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            JOptionPane.showMessageDialog(null, "An error occurred while linking judge and breed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public static void deleteJ(DefaultTableModel model, JTable table) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int confirmation = JOptionPane.showConfirmDialog(
                    null,
                    "Are you sure you want to delete the selected judge?",
                    "Confirm Deletion",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );
    
            if (confirmation == JOptionPane.YES_OPTION) {
                EntityManager em = null;
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
    
                    String judgeName = model.getValueAt(selectedRow, 0).toString();
                    String judgeSurname = model.getValueAt(selectedRow, 1).toString();
                    judgelist judge = em.createQuery("SELECT j FROM judgelist j WHERE j.judge_name = :name AND j.judge_surname = :surname", judgelist.class)
                            .setParameter("name", judgeName)
                            .setParameter("surname", judgeSurname)
                            .getSingleResult();
    
                    if (judge != null) {
                        Query deleteLinksQuery = em.createQuery("DELETE FROM breed_judge_list bjl WHERE bjl.id_of_judge = :judgeId");
                        deleteLinksQuery.setParameter("judgeId", judge.getJid());
                        deleteLinksQuery.executeUpdate();
                        em.remove(judge);
                        em.getTransaction().commit();
                        model.removeRow(selectedRow);
                        JOptionPane.showMessageDialog(null, "Judge successfully deleted.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Judge not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    JOptionPane.showMessageDialog(null, "An error occurred while deleting the judge: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    if (em != null) {
                        em.close();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Deletion canceled.", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Select a row to delete.", "Selection Error", JOptionPane.ERROR_MESSAGE);
        }
    }}