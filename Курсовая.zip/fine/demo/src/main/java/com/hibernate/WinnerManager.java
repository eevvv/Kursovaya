package com.hibernate;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class WinnerManager {
    static EntityManagerFactory emf = Persistence.createEntityManagerFactory("test_persistence");

    public static void loadWinners(DefaultTableModel model) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<winnerslist> winners = em.createQuery("SELECT w FROM winnerslist w JOIN w.dog d WHERE w.id_winner > 0", winnerslist.class).getResultList();
        model.setRowCount(0);
    
        if (winners.isEmpty()) {
            System.out.println("NO ROWS IN TABLE");
        } else {
            for (winnerslist winner : winners) {
                dog winningDog = winner.getDog(); 
                String dogName = winningDog != null ? winningDog.getDname() : "Unknown"; 
                String breedName = winningDog != null && winningDog.getBname() != null ? winningDog.getBname().getBname() : "Unknown"; 
                model.addRow(new Object[]{winner.getWid(), dogName, breedName});
            }
        }
    
        em.getTransaction().commit();
        em.close();
    }

    public static void addWinner(DefaultTableModel model, int winnerDogId) {
        EntityManager em = DogManager.emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        
        try {
            transaction.begin();
            dog winningDog = em.find(dog.class, winnerDogId);
            if (winningDog == null) {
                throw new Exception("Dog not found with ID: " + winnerDogId);
            }
            winnerslist newWinner = new winnerslist();
            newWinner.setDid(winningDog); 
    
            em.persist(newWinner);
    
            transaction.commit();
            List<winnerslist> winnersWithEmptyDogId = em.createQuery(
                "SELECT w FROM winnerslist w WHERE w.dog IS NULL", winnerslist.class).getResultList();
            if (!winnersWithEmptyDogId.isEmpty()) {
                transaction.begin(); 
                for (winnerslist winner : winnersWithEmptyDogId) {
                    winner.setDid(winningDog); 
                    em.merge(winner); 
                }
                transaction.commit(); 
            }
    
            model.addRow(new Object[]{
                newWinner.getWid(), 
                winningDog.getDname(), 
                winningDog.getBname() != null ? winningDog.getBname().getBname() : "Unknown" 
            });
        } catch (Exception ex) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            JOptionPane.showMessageDialog(null, "An error occurred while adding the winner: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            em.close();
        }
    }
    
    public static void editWinner(DefaultTableModel model, JTable table) {
    int selectedRow = table.getSelectedRow();
    if (selectedRow != -1) {
        int winnerId = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
        EntityManager em = emf.createEntityManager();
        winnerslist winner = em.find(winnerslist.class, winnerId);
        
        if (winner != null) {
            String[] dogNames = getDogNames(em); 
            String newDogName = (String) JOptionPane.showInputDialog(
                null,
                "Select a new dog:",
                "Edit Winner",
                JOptionPane.QUESTION_MESSAGE,
                null,
                dogNames,
                dogNames[0]
            );

            if (newDogName != null) {
                dog newDog = findDogByName(em, newDogName);
                if (newDog != null) {
                    winner.setDid(newDog);
                    
                    EntityTransaction transaction = em.getTransaction();
                    try {
                        transaction.begin();
                        em.merge(winner); 
                        transaction.commit();
                        
                        model.setValueAt(newDog.getDname(), selectedRow, 1); 
                        model.setValueAt(newDog.getBname() != null ? newDog.getBname().getBname() : "Unknown", selectedRow, 2);
                    } catch (Exception e) {
                        if (transaction.isActive()) {
                            transaction.rollback();
                        }
                        JOptionPane.showMessageDialog(null, "An error occurred while updating the winner: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Selected dog not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Winner not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        em.close();
    } else {
        JOptionPane.showMessageDialog(null, "Select a row to edit.", "Selection Error", JOptionPane.ERROR_MESSAGE);
    }
}
private static String[] getDogNames(EntityManager em) {
    List<dog> dogs = em.createQuery("SELECT d FROM dog d", dog.class).getResultList();
    return dogs.stream().map(d -> d.getDname()).toArray(String[]::new);
}

private static dog findDogByName(EntityManager em, String dogName) {
    List<dog> dogs = em.createQuery("SELECT d FROM dog d WHERE d.dogname = :dogname", dog.class)
                       .setParameter("dogname", dogName)
                       .getResultList();
    return dogs.isEmpty() ? null : dogs.get(0);
}

    public static void deleteWinner(DefaultTableModel model, JTable table) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int confirmation = JOptionPane.showConfirmDialog(
                    null,
                    "Are you sure you want to delete the selected winner?",
                    "Confirm Deletion",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );
            if (confirmation == JOptionPane.YES_OPTION) {
                EntityManager em = null;
                try {
                    em = emf.createEntityManager();
                    em.getTransaction().begin();
                    int winnerId = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
                    winnerslist winner = em.find(winnerslist.class, winnerId);
    
                    if (winner != null) {
                        em.remove(winner); 
                        em.getTransaction().commit();
                        model.removeRow(selectedRow); 
                    } else {
                        JOptionPane.showMessageDialog(null, "Winner not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception e) {
                    if (em != null && em.getTransaction().isActive()) {
                        em.getTransaction().rollback();
                    }
                    JOptionPane.showMessageDialog(null, "An error occurred while deleting the winner: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    if (em != null) {
                        em.close();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Deletion canceled.", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Select a row to delete.", "Selection Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

}