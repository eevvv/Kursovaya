import javax.swing.table.DefaultTableModel; // Подключаем классы JUnit

import org.junit.After; // Подключаем методы Assert
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.hibernate.Entity; // Убедитесь, что этот импорт правильный

public class FilterTableTest {

    private Entity yourClassUnderTest = new Entity(); // Замените на ваш класс

    @BeforeClass // Фиксируем начало тестирования
    public static void allTestsStarted() {
        System.out.println("Start");
    }

    @AfterClass // Фиксируем конец тестирования
    public static void allTestsFinished() {
        System.out.println("End");
    }

    @Before // Фиксируем запуск теста
    public void testStarted() {
        System.out.println("Testing");
        // Инициализация currentModel с тестовыми данными
        Entity.currentModel = new DefaultTableModel();
        String[] columns = {"ID", "Name", "Surname"}; // Замените на ваши реальные колонки
        for (String column : columns) {
            Entity.currentModel.addColumn(column);
        }
        
        // Добавление тестовых данных
        Entity.currentModel.addRow(new Object[]{1, "John", "Doe"});
        Entity.currentModel.addRow(new Object[]{2, "Jane", "Smith"});
        Entity.currentModel.addRow(new Object[]{3, "Alice", "Johnson"});
        // Добавьте больше данных по необходимости
    }

    @After // Фиксируем завершение теста
    public void testFinished() {
        System.out.println("FINITA LA COMEDIA");
    }

    @Test(expected = Entity.CustomException.class) // Проверяем на появление исключения
    public void testFilterTableWithNull() throws Entity.CustomException {
        yourClassUnderTest.filterTable(null); // Ожидаем исключение при передаче null
    }

    @Test(expected = Entity.CustomException.class) // Проверяем на появление исключения
    public void testFilterTableWithEmptyString() throws Entity.CustomException {
        yourClassUnderTest.filterTable(""); // Ожидаем исключение при передаче пустой строки
    }

    @Test
    public void testFilterTableWithNoMatches() throws Entity.CustomException {
        int foundCount = yourClassUnderTest.filterTable("nonexistent"); // Поиск по несуществующему значению
        Assert.assertEquals(0, foundCount); // Ожидаем, что найдено 0 элементов
    }

    @Test
    public void testFilterTableWithMatches() throws Entity.CustomException {
        int foundCount = yourClassUnderTest.filterTable("John"); // Поиск по существующему значению
        Assert.assertTrue(foundCount > 0); // Ожидаем, что найдено больше 0 элементов
    }

    @Test
    public void testFilterTableWithMixedResults() throws Entity.CustomException {
        int foundCount = yourClassUnderTest.filterTable("Jane"); // Поиск по значению, которое частично совпадает
        Assert.assertTrue(foundCount > 0); // Ожидаем, что найдено больше 0 элементов
    }
}